"""
dashboard/app.py
─────────────────
Full Streamlit dashboard showing:
  - Live pipeline health per table
  - Anomaly timeline with AI diagnoses
  - Repair log with before/after proof
  - Verification results
  - Per-table metric trends

Deploy free: streamlit run dashboard/app.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime, timedelta

from src.config import config
from src.models import init_db, PipelineSnapshot, AnomalyRecord, RepairLog, get_session

st.set_page_config(page_title="AI Pipeline Agent", page_icon="🤖", layout="wide")
init_db()
session = get_session()

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("🤖 AI Pipeline Agent")
    st.caption("Detects · Diagnoses · Repairs · Verifies")
    st.divider()

    selected_table = st.selectbox("Focus table", ["All"] + config.TABLES_TO_MONITOR)
    lookback = st.selectbox("Window", [7,14,30,60], index=2,
                            format_func=lambda x: f"Last {x} days")
    st.divider()

    col1, col2 = st.columns(2)
    if col1.button("▶ Run agent", use_container_width=True):
        with st.spinner("Agent running..."):
            from src.agent.agent import PipelineAgent
            from src.models import init_db
            init_db()
            summary = PipelineAgent().run()
        st.success(f"Done! {summary['anomalies_found']} anomaly(ies), {summary['repairs_attempted']} repair(s)")
        st.rerun()

    if col2.button("🔍 Detect only", use_container_width=True):
        with st.spinner("Scanning..."):
            import os; os.environ["AUTO_REPAIR"] = "false"
            config.AUTO_REPAIR = False
            from src.agent.agent import PipelineAgent
            summary = PipelineAgent().run()
            config.AUTO_REPAIR = True
        st.info(f"{summary['anomalies_found']} anomaly(ies) found")
        st.rerun()

    st.divider()
    st.caption(f"Auto-repair: {'ON' if config.AUTO_REPAIR else 'OFF'}")
    st.caption(f"Interval: {config.CHECK_INTERVAL_MINUTES} min")
    st.caption(f"Threshold: Z > {config.ANOMALY_THRESHOLD}")


# ── Load data ─────────────────────────────────────────────────────────────────
cutoff = datetime.utcnow() - timedelta(days=lookback)

snap_q = session.query(PipelineSnapshot).filter(PipelineSnapshot.checked_at >= cutoff)
anom_q = session.query(AnomalyRecord).filter(AnomalyRecord.detected_at >= cutoff)
repa_q = session.query(RepairLog).filter(RepairLog.started_at >= cutoff)

if selected_table != "All":
    snap_q = snap_q.filter(PipelineSnapshot.table_name == selected_table)
    anom_q = anom_q.filter(AnomalyRecord.table_name == selected_table)
    repa_q = repa_q.filter(RepairLog.table_name == selected_table)

snaps    = snap_q.order_by(PipelineSnapshot.checked_at.desc()).all()
anomalies = anom_q.order_by(AnomalyRecord.detected_at.desc()).all()
repairs  = repa_q.order_by(RepairLog.started_at.desc()).all()

df_s = pd.DataFrame([{
    "table":s.table_name,"checked_at":s.checked_at,
    "row_count":s.row_count,"null_rate":s.null_rate_avg,
} for s in snaps])

df_a = pd.DataFrame([{
    "table":a.table_name,"detected_at":a.detected_at,
    "type":a.anomaly_type,"severity":a.severity,
    "metric":a.metric_name,"observed":a.metric_value,
    "expected":a.expected_value,"z_score":a.z_score,
    "diagnosis":a.ai_diagnosis,"repair":a.repair_chosen,
    "status":a.repair_status,
} for a in anomalies])

df_r = pd.DataFrame([{
    "table":r.table_name,"action":r.repair_action,
    "rows_before":r.rows_before,"rows_after":r.rows_after,
    "null_before":r.null_rate_before,"null_after":r.null_rate_after,
    "success":r.success,"verified":r.verified,
    "detail":r.repair_detail,"started":r.started_at,
} for r in repairs])


# ── Header ────────────────────────────────────────────────────────────────────
st.title("🤖 AI Pipeline Agent — Live Dashboard")

# ── Summary cards ─────────────────────────────────────────────────────────────
c1, c2, c3, c4, c5 = st.columns(5)
critical = len(df_a[df_a["severity"]=="critical"]) if not df_a.empty else 0
verified = len(df_r[df_r["verified"]==True]) if not df_r.empty else 0
success_rate = f"{verified/len(df_r)*100:.0f}%" if not df_r.empty and len(df_r)>0 else "—"

c1.metric("Tables monitored", len(config.TABLES_TO_MONITOR))
c2.metric("Anomalies detected", len(df_a), delta=f"{critical} critical" if critical else None)
c3.metric("Repairs attempted", len(df_r))
c4.metric("Verified fixed", verified)
c5.metric("Success rate", success_rate)

st.divider()

# ── Anomaly + Repair timeline ─────────────────────────────────────────────────
st.subheader("Anomaly + repair log")

if df_a.empty:
    st.success("No anomalies detected in the selected window.")
else:
    for _, row in df_a.iterrows():
        sev_icon = "🔴" if row["severity"] == "critical" else "🟡"
        repair_rows = df_r[df_r["table"] == row["table"]] if not df_r.empty else pd.DataFrame()

        with st.expander(
            f"{sev_icon} **{row['table']}** — {row['type'].replace('_',' ')} "
            f"| Z={row['z_score']:.1f} | {row['detected_at'].strftime('%m/%d %H:%M')} "
            f"| Repair: `{row['repair'] or 'none'}` | Status: `{row['status'] or 'pending'}`",
            expanded=(row["severity"] == "critical"),
        ):
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Observed", f"{row['observed']:,.1f}")
            col2.metric("Expected", f"{row['expected']:,.1f}")
            col3.metric("Z-score",  f"{row['z_score']:.2f}σ")
            col4.metric("Severity", row["severity"].capitalize())

            if row["diagnosis"]:
                st.info(f"**AI Diagnosis**\n\n{row['diagnosis']}")

            if not repair_rows.empty:
                st.markdown("**Repair outcome**")
                r = repair_rows.iloc[0]
                rc1, rc2, rc3, rc4 = st.columns(4)
                rc1.metric("Rows before",  f"{r['rows_before']:,}")
                rc2.metric("Rows after",   f"{r['rows_after']:,}",
                           delta=f"{r['rows_after']-r['rows_before']:+,}")
                rc3.metric("Null before",  f"{r['null_before']:.1%}")
                rc4.metric("Null after",   f"{r['null_after']:.1%}")

                if r["success"] and r["verified"]:
                    st.success(f"✅ Verified fixed: {r['detail']}")
                elif r["success"]:
                    st.warning(f"⚠️ Repair ran but verification pending: {r['detail']}")
                else:
                    st.error(f"❌ Repair failed: {r['detail']}")

st.divider()

# ── Row count trend ────────────────────────────────────────────────────────────
st.subheader("Row count trend")
if not df_s.empty:
    fig = go.Figure()
    for tbl in df_s["table"].unique():
        tdf = df_s[df_s["table"]==tbl].sort_values("checked_at")
        fig.add_trace(go.Scatter(x=tdf["checked_at"], y=tdf["row_count"],
                                 name=tbl, mode="lines+markers"))
    if not df_a.empty:
        anoms = df_a[df_a["metric"]=="row_count"]
        if not anoms.empty:
            fig.add_trace(go.Scatter(
                x=anoms["detected_at"], y=anoms["observed"],
                mode="markers", marker=dict(symbol="x",size=12,color="#E24B4A"),
                name="Anomaly detected"))
    if not df_r.empty:
        fig.add_trace(go.Scatter(
            x=df_r["started"], y=df_r["rows_after"],
            mode="markers", marker=dict(symbol="star",size=14,color="#1D9E75"),
            name="After repair"))
    fig.update_layout(height=300, margin=dict(l=0,r=0,t=20,b=0),
                      legend=dict(orientation="h"), yaxis_title="Row count")
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info("Run the agent to populate charts.")

st.divider()

# ── Repair log table ───────────────────────────────────────────────────────────
st.subheader("Repair log")
if not df_r.empty:
    display = df_r[["started","table","action","rows_before","rows_after","success","verified","detail"]].copy()
    display.columns = ["Time","Table","Action","Rows before","Rows after","Success","Verified","Detail"]
    st.dataframe(display, use_container_width=True, hide_index=True)
else:
    st.caption("No repairs logged yet.")

st.caption("AI Pipeline Agent — Detect · Diagnose · Repair · Verify")
