"""
repairs/verifier.py
────────────────────
After a repair runs, the verifier re-profiles the table and checks
whether the anomaly that triggered the repair has been resolved.

Returns verified=True only if:
  - Row count is back within 1.5 standard deviations of baseline
  - Null rate is back below the threshold
  - No new anomalies appeared as a result of the repair
"""
import numpy as np
from src.models import AnomalyRecord, PipelineSnapshot, get_session
from src.profiler import TableProfiler
from src.config import config
from rich.console import Console

console = Console()


class RepairVerifier:
    def __init__(self):
        self.profiler = TableProfiler()
        self.session  = get_session()

    def verify(self, anomaly: AnomalyRecord, repair_result) -> bool:
        """
        Re-profiles the table and checks if the anomaly metric is now normal.
        Returns True if verified fixed, False if still broken.
        """
        console.print(f"  [cyan]Verifying repair...[/cyan]")

        fresh = self.profiler.profile_table(anomaly.table_name)
        if fresh.get("error"):
            console.print(f"  [red]Verification failed — couldn't profile table[/red]")
            return False

        metric  = anomaly.metric_name
        current = fresh.get(metric)

        if current is None:
            return True   # metric no longer measurable = likely resolved

        # Get historical baseline
        from datetime import datetime, timedelta
        cutoff = datetime.utcnow() - timedelta(days=config.LOOKBACK_DAYS)
        history = (self.session.query(PipelineSnapshot)
                   .filter(PipelineSnapshot.table_name == anomaly.table_name,
                           PipelineSnapshot.checked_at >= cutoff)
                   .all())

        hist_vals = [getattr(s, metric) for s in history
                     if getattr(s, metric) is not None]

        if len(hist_vals) < 3:
            # Not enough history — accept if rows increased
            if metric == "row_count":
                resolved = repair_result.rows_after > repair_result.rows_before
            else:
                resolved = True
        else:
            mean = np.mean(hist_vals)
            std  = np.std(hist_vals)
            if std < 1e-9:
                resolved = True
            else:
                new_z = abs((current - mean) / std)
                # Resolved if new Z-score is within 1.5 sigma (well within normal)
                resolved = new_z < 1.5

        status = "[green]VERIFIED ✓[/green]" if resolved else "[yellow]STILL ANOMALOUS[/yellow]"
        console.print(f"  Verification: {status}")
        console.print(f"  Current {metric}: {current} (was {anomaly.metric_value})")

        return resolved
