"""
llm/llm_brain.py
─────────────────
The AI brain of the agent. Does TWO things:

  1. DIAGNOSE  — explains what broke and why in plain English
  2. DECIDE    — picks the best repair action from the available toolkit

The repair decision is returned as structured JSON so the agent
can execute it without any human in the loop.

Available repair actions the LLM can choose:
  - reingest_missing_rows   : re-runs the ingestion for the affected time window
  - repair_null_values      : fills NULLs with column median / mode / default
  - remove_duplicate_rows   : deduplicates based on primary key
  - rollback_schema_change  : reverts column renames or type changes
  - refresh_stale_table     : triggers a full table reload
  - quarantine_bad_rows     : moves rows failing validation to a quarantine table
  - no_action               : issue is known/acceptable, just log and alert
"""
import json
from src.config import config
from src.models import AnomalyRecord, PipelineSnapshot

REPAIR_ACTIONS = [
    "reingest_missing_rows",
    "repair_null_values",
    "remove_duplicate_rows",
    "rollback_schema_change",
    "refresh_stale_table",
    "quarantine_bad_rows",
    "no_action",
]


def build_diagnosis_prompt(anomaly: AnomalyRecord, snapshot: PipelineSnapshot, history: list) -> str:
    recent_vals = [str(getattr(s, anomaly.metric_name, "N/A")) for s in history[-7:]]
    history_str = ", ".join(recent_vals) if recent_vals else "no history"

    return f"""You are an autonomous AI data engineering agent. A pipeline anomaly has been detected.
Your job is to:
1. Diagnose the root cause in plain English (2-3 sentences)
2. Select the best automated repair action from the list below

ANOMALY DETAILS
───────────────
Table:          {anomaly.table_name}
Anomaly type:   {anomaly.anomaly_type}
Metric:         {anomaly.metric_name}
Observed:       {anomaly.metric_value}
Expected:       {anomaly.expected_value}
Z-score:        {anomaly.z_score}
Severity:       {anomaly.severity}
Detected at:    {anomaly.detected_at}

TABLE STATE
───────────
Row count:       {snapshot.row_count:,}
Null rate avg:   {snapshot.null_rate_avg:.1%}
Column count:    {snapshot.column_count}
Schema changed:  {snapshot.schema_changed}
Hours stale:     {snapshot.hours_since_update or 'unknown'}
Last 7 readings: {history_str}

AVAILABLE REPAIR ACTIONS
────────────────────────
- reingest_missing_rows   : re-runs data ingestion for missing time window
- repair_null_values      : fills NULL columns with median/mode/sensible default
- remove_duplicate_rows   : removes duplicate records keeping latest
- rollback_schema_change  : reverts unexpected column changes
- refresh_stale_table     : forces a full reload of the table
- quarantine_bad_rows     : isolates rows failing validation rules
- no_action               : anomaly is acceptable, just log it

Respond ONLY with this exact JSON (no markdown, no extra text):
{{
  "diagnosis": "2-3 sentence plain English explanation of root cause",
  "repair_action": "one of the action names above",
  "repair_reason": "one sentence why this repair was chosen",
  "confidence": 0.0-1.0,
  "estimated_rows_recovered": number or null
}}"""


def call_llm(prompt: str) -> dict:
    """Calls GPT-4o or Claude and parses the JSON response."""
    raw = ""
    model_used = "template"

    try:
        if config.LLM_PROVIDER == "anthropic" and config.ANTHROPIC_API_KEY:
            import anthropic
            client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
            resp = client.messages.create(
                model="claude-sonnet-4-6", max_tokens=600,
                messages=[{"role": "user", "content": prompt}]
            )
            raw = resp.content[0].text.strip()
            model_used = "claude-sonnet-4-6"

        elif config.OPENAI_API_KEY:
            from openai import OpenAI
            client = OpenAI(api_key=config.OPENAI_API_KEY)
            resp = client.chat.completions.create(
                model="gpt-4o", max_tokens=600, temperature=0.2,
                messages=[
                    {"role": "system", "content": "You are a data engineering AI agent. Always respond with valid JSON only."},
                    {"role": "user", "content": prompt},
                ]
            )
            raw = resp.choices[0].message.content.strip()
            model_used = "gpt-4o"

        # Strip markdown code fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]

        result = json.loads(raw)
        result["model_used"] = model_used
        return result

    except Exception as e:
        # Fallback: rule-based decision without LLM
        return _fallback_decision(e)


def _fallback_decision(error=None) -> dict:
    """Rule-based fallback when no API key is set."""
    return {
        "diagnosis": "Anomaly detected via statistical analysis. No LLM API key configured — using rule-based diagnosis.",
        "repair_action": "no_action",
        "repair_reason": "No API key available for AI-driven repair selection.",
        "confidence": 0.5,
        "estimated_rows_recovered": None,
        "model_used": "fallback",
    }


class LLMBrain:
    def diagnose_and_decide(
        self,
        anomaly: AnomalyRecord,
        snapshot: PipelineSnapshot,
        history: list,
    ) -> dict:
        """
        Returns a dict with keys:
          diagnosis, repair_action, repair_reason, confidence,
          estimated_rows_recovered, model_used
        """
        prompt = build_diagnosis_prompt(anomaly, snapshot, history)
        result = call_llm(prompt)

        # Validate repair action is one we know
        if result.get("repair_action") not in REPAIR_ACTIONS:
            result["repair_action"] = "no_action"

        return result
