"""
tests/test_agent.py — automated tests for all major components
Run with: pytest tests/ -v
"""
import pytest
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

from src.models import PipelineSnapshot, AnomalyRecord, RepairLog
from src.detectors.detector import AnomalyDetector
from src.llm.llm_brain import LLMBrain, _fallback_decision
from src.repairs.repair_engine import RepairEngine


# ── Fixtures ──────────────────────────────────────────────────────────────────

def make_snap(row_count=19000, null_rate=0.02, schema="aaa", hours=1.0):
    return PipelineSnapshot(
        id=99, table_name="orders", checked_at=datetime.utcnow(),
        row_count=row_count, null_rate_avg=null_rate,
        distinct_rate_avg=0.85, column_count=6,
        schema_hash=schema, hours_since_update=hours,
    )

def make_history(n=25, mean=19000, std=400):
    import random; random.seed(42)
    return [PipelineSnapshot(
        id=i, table_name="orders",
        checked_at=datetime.utcnow()-timedelta(days=n-i),
        row_count=max(1,int(random.gauss(mean,std))),
        null_rate_avg=max(0,random.gauss(0.02,0.005)),
        distinct_rate_avg=0.85, schema_hash="aaa",
    ) for i in range(n)]


# ── Detector tests ────────────────────────────────────────────────────────────

class TestDetector:
    def setup_method(self):
        self.d = AnomalyDetector()
        self.d._get_history = MagicMock(return_value=make_history())

    def test_normal_data_no_anomaly(self):
        snap = make_snap(row_count=19100)
        assert len([a for a in self.d.detect(snap) if a.metric_name=="row_count"]) == 0

    def test_detects_row_drop(self):
        snap = make_snap(row_count=1200)
        anoms = [a for a in self.d.detect(snap) if a.anomaly_type=="row_count_drop"]
        assert len(anoms) == 1
        assert anoms[0].z_score < -3.0

    def test_detects_null_spike(self):
        snap = make_snap(null_rate=0.80)
        anoms = [a for a in self.d.detect(snap) if a.anomaly_type=="null_rate_spike"]
        assert len(anoms) == 1

    def test_detects_schema_change(self):
        snap = make_snap(schema="DIFFERENT_HASH")
        anoms = [a for a in self.d.detect(snap) if a.anomaly_type=="schema_change"]
        assert len(anoms) == 1

    def test_detects_stale_data(self):
        snap = make_snap(hours=30.0)
        anoms = [a for a in self.d.detect(snap) if a.anomaly_type=="stale_data"]
        assert len(anoms) == 1

    def test_insufficient_history_skips(self):
        self.d._get_history = MagicMock(return_value=make_history(n=2))
        snap = make_snap(row_count=1)
        assert self.d.detect(snap) == []

    def test_critical_severity_at_high_z(self):
        snap = make_snap(row_count=100)
        anoms = self.d.detect(snap)
        rc = [a for a in anoms if a.metric_name=="row_count"]
        if rc:
            assert rc[0].severity == "critical"


# ── LLM Brain tests ───────────────────────────────────────────────────────────

class TestLLMBrain:
    def test_fallback_returns_valid_structure(self):
        result = _fallback_decision()
        assert "diagnosis" in result
        assert "repair_action" in result
        assert result["repair_action"] == "no_action"

    def test_brain_returns_no_action_without_key(self):
        with patch("src.config.config.OPENAI_API_KEY", ""), \
             patch("src.config.config.ANTHROPIC_API_KEY", ""):
            brain = LLMBrain()
            anomaly = AnomalyRecord(
                table_name="orders", anomaly_type="row_count_drop",
                metric_name="row_count", metric_value=1200,
                expected_value=19000, z_score=-45.0,
                severity="critical", detected_at=datetime.utcnow(),
            )
            snap = make_snap()
            result = brain.diagnose_and_decide(anomaly, snap, [])
            assert "diagnosis" in result
            assert result["repair_action"] in [
                "reingest_missing_rows","repair_null_values","remove_duplicate_rows",
                "rollback_schema_change","refresh_stale_table","quarantine_bad_rows","no_action"
            ]


# ── Repair Engine tests (uses in-memory SQLite) ───────────────────────────────

class TestRepairEngine:
    def setup_method(self):
        self.engine = RepairEngine(db_url="sqlite:///:memory:")
        # Create test table
        from sqlalchemy import text
        with self.engine.engine.connect() as conn:
            conn.execute(text("""CREATE TABLE orders (
                id INTEGER PRIMARY KEY, user_id INTEGER,
                amount REAL, status TEXT,
                created_at TEXT, updated_at TEXT)"""))
            for i in range(100):
                conn.execute(text(
                    "INSERT INTO orders VALUES (:id,:uid,:amt,:st,:ca,:ua)"
                ), {"id":i+1,"uid":i+2,"amt":50.0,"st":"completed",
                    "ca":"2024-01-01","ua":"2024-01-01"})
            conn.commit()

    def test_no_action_always_succeeds(self):
        r = self.engine.execute("no_action","orders",{})
        assert r.success is True

    def test_repair_null_values(self):
        from sqlalchemy import text
        with self.engine.engine.connect() as conn:
            conn.execute(text("UPDATE orders SET status=NULL WHERE id <= 50"))
            conn.commit()
        r = self.engine.execute("repair_null_values","orders",{})
        assert r.success is True
        assert r.null_rate_after < r.null_rate_before

    def test_remove_duplicates(self):
        from sqlalchemy import text
        with self.engine.engine.connect() as conn:
            for i in range(50):
                conn.execute(text(
                    "INSERT INTO orders (user_id,amount,status,created_at,updated_at) VALUES (1,50,'completed','2024-01-01','2024-01-01')"
                ))
            conn.commit()
        before = self.engine._snapshot("orders")[0]
        r = self.engine.execute("remove_duplicate_rows","orders",{})
        assert r.success is True

    def test_reingest_missing_rows(self):
        r = self.engine.execute("reingest_missing_rows","orders",{
            "expected_value":200,"metric_value":100
        })
        assert r.success is True
        assert r.rows_after >= r.rows_before
